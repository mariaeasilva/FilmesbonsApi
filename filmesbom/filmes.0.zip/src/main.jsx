import React from 'react'
import ReactDOM from 'react-dom/client'
import Filmes from './filmes.jsx'
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Filmes />
  </React.StrictMode>,
)
